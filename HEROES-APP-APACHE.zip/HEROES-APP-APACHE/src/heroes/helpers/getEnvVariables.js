// Sin vite
// export const getEnvVariables = () => {
 
//     return {
//         ...process.env
//     }

// }

// Con vite
export const getEnvVariables = () => {
 
    // * Importante siempre dejar esta línea así, de lo contrario no funcionaría las variables de entorno
    import.meta.env

    return {
        ...import.meta.env,
    }

}