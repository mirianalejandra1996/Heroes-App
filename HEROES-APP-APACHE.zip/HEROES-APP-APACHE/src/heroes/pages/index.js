
export * from './DcPage';
export * from './HeroPage';
export * from './MarvelPage';
export * from './SearchPage';