import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
// import envVariables from 'vite-env-variables';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/heroes-spa/',
  // ...envVariables(),
})
